package org.rahul.assessment.lighthouse.database;

import java.util.HashMap;
import java.util.Map;

import org.rahul.assessment.lighthouse.model.Appointment;

public class DatabaseClass {
	
	private static Map<Long, Appointment> appointments = new HashMap<>();

	public static Map<Long, Appointment> getAppointments() {
		return appointments;
	}

	

}
