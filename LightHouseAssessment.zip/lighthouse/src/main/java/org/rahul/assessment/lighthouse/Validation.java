package org.rahul.assessment.lighthouse;

import java.time.Instant;

//This Class validates the appointments

public class Validation {
	
	/* Validation function for startTime and endTime must both be valid times, 
	 * and in the future */
	public boolean isLaterTime(long startTime,long endTime) {
		long currentTime = Instant.now().getEpochSecond();
		if(currentTime<startTime && currentTime<endTime) {
			return true;
		}
		else
		return false;
	}
	
	
	/* Validation function for A dental appointment should be at 
	 * least 30 minutes */
	public boolean isthirtyInterval(long startTime,long endTime) {
		
		if(endTime - startTime >= 1800) {
			return true;
		}
		else
		return false;
	}
	
	
	
	
}
