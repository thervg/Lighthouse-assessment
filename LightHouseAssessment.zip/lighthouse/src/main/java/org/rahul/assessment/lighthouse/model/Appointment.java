package org.rahul.assessment.lighthouse.model;


public class Appointment {

	private long id;
	private long startTime;
	private long endTime;
	private int dentist_id;
	private int patient_id;
	
	public Appointment() {
	
	}
	
	
	public long getstartTime() {
		return startTime;
	}
	public void setstartTime(long startTime) {
		this.startTime = startTime;
	}
	public long getendTime() {
		return endTime;
	}
	public void setendTime(long endTime) {
		this.endTime = endTime;
	}
	public int getdentist_id() {
		return dentist_id;
	}
	public void setdentist_id(int dentist_id) {
		this.dentist_id = dentist_id;
	}
	public int getpatient_id() {
		return patient_id;
	}
	public void setpatient_id(int patient_id) {
		this.patient_id = patient_id;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
}
