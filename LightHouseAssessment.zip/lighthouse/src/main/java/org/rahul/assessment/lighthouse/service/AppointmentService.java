package org.rahul.assessment.lighthouse.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.rahul.assessment.lighthouse.database.DatabaseClass;
import org.rahul.assessment.lighthouse.model.Appointment;

public class AppointmentService {
	
	private Map<Long, Appointment> appointments = DatabaseClass.getAppointments();

	public List<Appointment> getAllAppointments(){
		return new ArrayList<Appointment>(appointments.values());
	}
	
	public Appointment addAppointment(Appointment appointment) {
		appointment.setId(appointments.size() +1);
		appointments.put(appointment.getId(), appointment);
		return appointment;
	}
	
	public Appointment getAppointment(long id) {
		return appointments.get(id);
	}
	
	
/* Validation function for Two appointments for the same dentist can't start at 
 * the same time (appointments CAN overlap, but 2 appointments for 1 dentist 
 * should not start at the exact same time */	
public boolean isStartTimeUniqueForDentist(int dentistId,long startTime) {
		Iterator<Map.Entry<Long,Appointment>> appIt = appointments.entrySet().iterator();
		while(appIt.hasNext()) {
		Map.Entry<Long, Appointment> entry = appIt.next();
		Appointment appt = entry.getValue();
		if(appt.getdentist_id()==dentistId && appt.getstartTime()==startTime) {
			//break;
			return false;
		}
		}
		return true;
	}
}
