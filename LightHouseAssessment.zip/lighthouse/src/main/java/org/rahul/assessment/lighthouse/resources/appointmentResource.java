package org.rahul.assessment.lighthouse.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.rahul.assessment.lighthouse.Validation;
import org.rahul.assessment.lighthouse.model.Appointment;
import org.rahul.assessment.lighthouse.service.AppointmentService;
//URL: http://localhost:8080/lighthouse/assessment
@Path("/dentalAppointments/")
public class appointmentResource {
	AppointmentService apptService = new AppointmentService();
	Validation validation = new Validation();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Appointment> getAllAppointments(){
		return apptService.getAllAppointments();
	}
	
	
	
	@GET
	@Path("/{appointmentId}/")
	@Produces(MediaType.APPLICATION_JSON)
	public Appointment getAppointment(@PathParam("appointmentId") long id){
		return apptService.getAppointment(id);
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addAppointment(Appointment appointment){
		if(validation.isLaterTime(appointment.getstartTime(), appointment.getendTime())
			&& validation.isthirtyInterval(appointment.getstartTime(), appointment.getendTime())	
				&& apptService.isStartTimeUniqueForDentist(appointment.getdentist_id(), appointment.getstartTime())
				) {
		Appointment newAppointment = apptService.addAppointment(appointment);
		return Response.status(Status.CREATED)
				.entity(newAppointment)
				.build();
		}
		else {
			
			return Response.status(Status.OK)
					.build();
		}
		
	}

}
